package com.example.input_e_dialog

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
